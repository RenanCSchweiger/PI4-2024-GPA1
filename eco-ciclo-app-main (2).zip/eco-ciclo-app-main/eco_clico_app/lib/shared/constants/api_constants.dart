class ApiConstants {
  static const String baseUrl = "https://46e0-2804-431-cfcb-6e0d-b006-90b8-fe70-8acf.ngrok.io";
  // static const String baseUrl = "http://172.21.64.1:8080";
}
