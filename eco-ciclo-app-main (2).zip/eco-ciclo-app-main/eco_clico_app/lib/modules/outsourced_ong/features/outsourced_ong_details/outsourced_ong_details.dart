export 'outsourced_ong_details_binding.dart';
export 'outsourced_ong_details_controller.dart';
export 'outsourced_ong_details_page.dart';
