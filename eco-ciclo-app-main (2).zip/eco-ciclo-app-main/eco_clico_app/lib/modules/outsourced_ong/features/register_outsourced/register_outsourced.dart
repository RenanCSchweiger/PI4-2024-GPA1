export 'register_outsourced_binding.dart';
export 'register_outsourced_controller.dart';
export 'register_outsourced_page.dart';
