package com.EcoCiclo.reciclagens.model.enums;

public enum TipoEmpresaEnum {
    terceirizada,
    ong
}
