package com.EcoCiclo.reciclagens;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcoCicloApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcoCicloApplication.class, args);
	}

}
