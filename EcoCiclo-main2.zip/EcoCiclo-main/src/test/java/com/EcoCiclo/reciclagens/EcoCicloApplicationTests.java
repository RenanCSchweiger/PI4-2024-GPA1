package com.EcoCiclo.reciclagens;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcoCicloApplicationTests {

	@Test
	void contextLoads() {
	}

}
